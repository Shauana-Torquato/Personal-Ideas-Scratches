package com.example.demo_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoManagementApplication.class, args);
	}

}
